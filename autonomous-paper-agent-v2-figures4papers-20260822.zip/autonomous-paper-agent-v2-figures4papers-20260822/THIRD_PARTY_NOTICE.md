# Third-party notice

`skills/scientific-figure-making` was extracted from the locally checked-out figures4papers repository:

- Upstream: https://github.com/ChenLiu-1996/figures4papers
- Commit: `6790a93af3552539d955d77181c818916e1700b7`
- Included scope: `scientific-figure-making/SKILL.md` and its `references/` only

The checked-out upstream repository did not contain a license file at packaging time. This bundle records provenance but does not grant additional redistribution rights. Confirm the upstream terms before public redistribution.
