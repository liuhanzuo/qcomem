# 安装

这个压缩包包含两个配套 skill：

- `skills/autonomous-paper-agent`：论文构建、证据审计、独立盲审、自迭代修改和 checkpoint 选择。
- `skills/scientific-figure-making`：从 figures4papers 提取的出版级 Matplotlib 绘图规范。

## Codex 项目级安装

在目标论文 repository 根目录运行：

```bash
mkdir -p .agents/skills .codex/agents
cp -R /path/to/unzipped-bundle/skills/autonomous-paper-agent .agents/skills/
cp -R /path/to/unzipped-bundle/skills/scientific-figure-making .agents/skills/
cp -R /path/to/unzipped-bundle/skills/autonomous-paper-agent/adapters/codex/.codex/agents/. .codex/agents/
```

将 `skills/autonomous-paper-agent/adapters/codex/.codex/config.toml.example` 中的配置合并到项目 `.codex/config.toml`；不要覆盖已有配置。重启或刷新 Codex 后调用 `$autonomous-paper-agent`。

## Claude Code 项目级安装

```bash
mkdir -p .claude/skills .claude/agents
cp -R /path/to/unzipped-bundle/skills/autonomous-paper-agent .claude/skills/
cp -R /path/to/unzipped-bundle/skills/scientific-figure-making .claude/skills/
cp -R /path/to/unzipped-bundle/skills/autonomous-paper-agent/adapters/claude/.claude/agents/. .claude/agents/
```

重启或刷新 Claude Code 后调用 `/autonomous-paper-agent`。

## 绘图路由

论文 skill 会把定量结果图、消融图、趋势图、热力图和多面板图路由到 `scientific-figure-making`。图中数值与标签必须来自论文已登记证据；概念性 teaser 或架构插图才可使用生成式图片，并且不能被当作实验依据。
