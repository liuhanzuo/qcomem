# ForkAudit ICLR 2026 research bundle

This is the complete, non-anonymous research bundle. It contains the English
ICLR manuscript and build inputs, figures/tables and derivation scripts,
anonymous supplement, independent review audit trail, official template ZIP,
the three original run-artifact directories used by the paper, their Chinese
reports, launch configurations, frozen protocol manifest, and a snapshot of
the ICLR-aligned autonomous-paper review skill, including its policy for using
ImageGen on non-evidentiary teasers and conceptual architecture illustrations.

The original experimental *outputs* are included byte-for-byte. Model weights
and PG-19 text are not redistributed; their expected digests and access
boundaries remain in the run ledgers. This archive is not double-blind because
the original run artifacts may contain local or infrastructure metadata.
