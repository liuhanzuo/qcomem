# Repository evidence inventory

This inventory was rebuilt without reading the archived manuscript or its reviews.

## Primary experiment

- Anonymous evidence root: `supplement_anonymous/raw_primary/`
- Aggregate: `supplement_anonymous/raw_primary/multifork-resident-summary.json`
- Raw shards: `supplement_anonymous/raw_primary/resident-shards/multifork-resident-shard-{0..7}.json`
- Anonymous integrity ledger: `supplement_anonymous/ANONYMOUS_MANIFEST.sha256`
- Original-byte digest binding: `supplement_anonymous/provenance/original_evidence_digests.json`
- Formal method files: `supplement_anonymous/code/` (18-file executed dependency closure, launcher, and protocol).

## Supporting same-kernel experiment

- Aggregate: `supplement_anonymous/raw_supporting/fair-v2-summary.json`
- Purpose: single-request same-kernel fair control, full-logit parity, and timing/memory boundary. It does not authorize a speedup claim.

## Negative compatibility experiment

- Aggregate: `supplement_anonymous/raw_supporting/cross-backend-negative-summary.json`
- Purpose: documents the failure of a Transformers-eager cross-backend compatibility gate. It prevents the same-kernel result from being generalized to eager-backend bitwise equivalence.

## Source and method files

- Paged Q16 arena and partial-tail COW: `supplement_anonymous/code/qcomem_vllm_paged_kernel.py`
- Qwen3.5 cache integration: `supplement_anonymous/code/qcomem_qwen35_vllm_paged_integration.py`
- Functional recurrent-state binding: `supplement_anonymous/code/qcomem_qwen35_native_cache.py`
- Multi-resident construction and ownership audit: `supplement_anonymous/code/qcomem_vllm_paged_multifork_resident.py`
- Formal execution, invariant replay, and aggregation: `supplement_anonymous/code/run_qcomem_qwen35_vllm_paged_multifork_resident.py`
- Frozen protocol and release governance: `supplement_anonymous/code/MULTIFORK_RESIDENT_PROTOCOL_ZH.md` and the launcher beside it.

## Evidence limitations

- One model family and one hardware family.
- One 4095-token, page-size-128 partial-tail geometry; N in {1,2,4,8,16,32}; 32-token queries and 8 greedy generation steps.
- Request objects coexist, but model steps execute serially on one CUDA stream in round-major order.
- No production vLLM engine scheduler, continuous batching, ragged batching, cancellation, eviction, throughput, TTFT, TPOT, NVML, F1/EM, Q8/Q4, multi-document, or aligned-4096 evaluation.
- The fresh control retains the source arena and its N-scaled private reservations, so `80+90N` versus `80+5N MiB` is a controlled ownership contrast, not an optimized production full-copy baseline.
- Eight ranks provide eight distinct books/query banks, but deterministic page-geometry values are not independent statistical memory replicates.
