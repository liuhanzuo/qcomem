# ForkAudit anonymous supplementary evidence

This directory is a deterministic, double-blind derivative of the frozen
research artifacts. The original run mirror is not modified.

- `code/` contains the 18 source/protocol files needed for offline replay and
  the 17 CPU governance tests. Every copied file matches a published per-file
  digest from the executed source set; the private 135-entry absolute-path
  ledger preimage is not redistributed, so completeness against that ledger is
  not independently reconstructible here.
- `raw_primary/` contains the aggregate, eight raw shards, and static audit.
  Identifying filesystem, cluster, and private-service metadata was redacted;
  the derivative summary rebinds the resulting shard hashes. Numeric values,
  digests of model outputs/state, and pass/fail booleans are unchanged.
- `raw_supporting/` contains the same-kernel single-request control summary and
  the cross-backend negative-gate summary under the same metadata redaction.
- `provenance/original_evidence_digests.json` binds the unredacted source bytes
  by role, basename, size, and SHA-256 without redistributing identifying paths.
  It also binds the complete original execution code-ledger file hash while
  explaining why the path-normalized derivative ledger has a different hash.
- `provenance/governance_tests.log` records a clean run from the copied source
  closure. Model weights and PG-19 text are not redistributed.

Deep-replay the raw cross-arm and cross-fan-out relations, storage/accounting
equations, and paper figures/tables from the anonymous primary evidence with:

```bash
python scripts/generate_paper_artifacts.py \
  --results supplement_anonymous/raw_primary \
  --output-root /tmp/forkaudit-replay
```

The evidence stores full-tensor SHA-256 digests and runtime `torch.equal`
booleans, not the full logits/KV/GDN tensors. Independent numerical replay
therefore still requires the pinned model and PG-19 inputs. This package is an
offline evidence-replay artifact, not a clean GPU-rerun artifact. The original
code ledger used absolute private paths and is not redistributed; the copied
source files are checked against their published per-file digests, while the
relative-path derivative ledger necessarily has a different whole-file hash.
