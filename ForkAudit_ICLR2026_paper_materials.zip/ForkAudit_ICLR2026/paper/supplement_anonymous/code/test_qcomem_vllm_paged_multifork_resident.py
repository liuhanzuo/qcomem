from __future__ import annotations

import unittest
from types import SimpleNamespace

import torch

from qcomem_qwen35_vllm_paged_integration import (
    convert_all_qwen35_full_layers_to_vllm_q16,
)
from qcomem_vllm_paged_fair_control import FRESH_CONTROL, SHARED_REUSE
from qcomem_vllm_paged_multifork_resident import (
    MULTIFORK_COUNTS,
    MULTIFORK_PROTOCOL,
    MultiForkHitLedger,
    QComemMultiForkError,
    build_deterministic_distinct_queries,
    build_pg19_train_query_bank,
    build_resident_request_group,
    linear_capacity_fit,
    resident_storage_breakdown,
    strict_group_logical_parity,
    validate_resident_group_ownership,
)


class LinearLayer:
    def __init__(self) -> None:
        self.conv_states = {0: torch.zeros(1, 2, 3)}
        self.recurrent_states = {0: torch.zeros(1, 2, 4, 4)}
        self.is_conv_states_initialized = {0: True}
        self.is_recurrent_states_initialized = {0: True}
        self.has_previous_state = {0: True}
        self.conv_kernel_size = {0: 3}
        self.record_past = False

    def lazy_initialization(self, **kwargs):
        del kwargs


class DenseFullLayer:
    is_sliding = False

    def __init__(self, seed: int, length: int) -> None:
        generator = torch.Generator().manual_seed(seed)
        self.keys = torch.randn(1, 2, length, 32, generator=generator)
        self.values = torch.randn(1, 2, length, 32, generator=generator)


def make_cache_and_plan(*, length: int, forks: int, max_append_tokens: int = 8):
    layer_types = [
        "full_attention" if (index + 1) % 4 == 0 else "linear_attention"
        for index in range(40)
    ]
    full = tuple(index for index, kind in enumerate(layer_types) if kind == "full_attention")
    linear = tuple(index for index, kind in enumerate(layer_types) if kind == "linear_attention")
    cache = SimpleNamespace(
        layers=[
            DenseFullLayer(1000 + index, length)
            if kind == "full_attention"
            else LinearLayer()
            for index, kind in enumerate(layer_types)
        ]
    )
    config = SimpleNamespace(layer_types=layer_types)
    plan = SimpleNamespace(
        full_attention_layer_indices=full,
        linear_layer_indices=linear,
        gdn=config,
    )
    conversion = convert_all_qwen35_full_layers_to_vllm_q16(
        cache,
        plan,
        page_size=16,
        max_append_tokens=max_append_tokens,
        max_request_forks=forks,
    )
    return cache, plan, conversion


class MarkerTokenizer:
    def encode(self, text: str, add_special_tokens: bool = False):
        del add_special_tokens
        digits = [ord(character) - ord("0") for character in text if character.isdigit()]
        return [71, 72, *(100 + digit for digit in digits), 73]


class ConstantTokenizer:
    def encode(self, text: str, add_special_tokens: bool = False):
        del text, add_special_tokens
        return [1, 2, 3]


class RawTokenizer:
    def encode(self, text: str, add_special_tokens: bool = False):
        del add_special_tokens
        return [index % 997 for index, _character in enumerate(text)]


class ZeroKernel:
    def __call__(self, **kwargs):
        kwargs["out"].zero_()


class MultiForkResidentTest(unittest.TestCase):
    def test_queries_are_deterministic_fixed_length_and_pairwise_distinct(self):
        base = torch.arange(24, dtype=torch.long).unsqueeze(0)
        first, audit = build_deterministic_distinct_queries(
            base, MarkerTokenizer(), count=32, query_tokens=32
        )
        second, second_audit = build_deterministic_distinct_queries(
            base, MarkerTokenizer(), count=32, query_tokens=32
        )
        self.assertTrue(audit["pairwise_distinct"])
        self.assertEqual(audit, second_audit)
        self.assertEqual(len(first), 32)
        self.assertTrue(all(tuple(value.shape) == (1, 32) for value in first))
        self.assertTrue(all(torch.equal(left, right) for left, right in zip(first, second)))
        self.assertEqual(len({row["query_token_ids_sha256"] for row in audit["rows"]}), 32)

    def test_duplicate_query_content_fails_closed(self):
        with self.assertRaisesRegex(QComemMultiForkError, "pairwise distinct"):
            build_deterministic_distinct_queries(
                torch.arange(32).unsqueeze(0),
                ConstantTokenizer(),
                count=4,
                query_tokens=32,
            )

    def test_formal_query_bank_uses_nonoverlapping_raw_pg19_train_chunks(self):
        source = "train/123.txt"
        records = [{"id": "123", "_source_object": source, "text": "x" * 10000}]
        window = SimpleNamespace(
            source_id="123",
            source_object=source,
            start_token=17,
        )
        queries, audit = build_pg19_train_query_bank(
            records,
            RawTokenizer(),
            window,
            document_tokens=4095,
            query_tokens=32,
            count=32,
            query_stride=64,
        )
        self.assertEqual(len(queries), 32)
        self.assertFalse(audit["synthetic_markers_used"])
        self.assertTrue(audit["pairwise_nonoverlapping"])
        self.assertEqual(audit["query_bank_start_token"], 17 + 4095 + 32)
        self.assertEqual(
            [row["source_token_offset"] for row in audit["rows"]],
            [17 + 4095 + 32 + index * 64 for index in range(32)],
        )
        self.assertEqual(len({row["query_token_ids_sha256"] for row in audit["rows"]}), 32)

    def test_fresh_and_reuse_hold_all_requests_with_exact_ownership(self):
        cache, plan, conversion = make_cache_and_plan(length=35, forks=4)
        fresh = build_resident_request_group(
            cache, plan, resident_count=4, policy=FRESH_CONTROL
        )
        reuse = build_resident_request_group(
            cache, plan, resident_count=4, policy=SHARED_REUSE
        )
        self.assertEqual(len(fresh.requests), 4)
        self.assertEqual(len(reuse.requests), 4)
        self.assertTrue(fresh.audit["all_requests_materialized_before_measurement"])
        self.assertTrue(reuse.audit["all_requests_materialized_before_measurement"])
        self.assertTrue(
            fresh.audit["ownership"]["fresh_request_arena_storages_pairwise_disjoint"]
        )
        self.assertTrue(reuse.audit["ownership"]["reuse_requests_share_source_arena"])
        self.assertTrue(
            reuse.audit["ownership"]["private_physical_reservation_ids_pairwise_disjoint"]
        )
        expected_document_copy = 4 * sum(
            cache.layers[index].arena.batch_size
            * cache.layers[index].arena.document_blocks_per_sequence
            * 2
            * cache.layers[index].arena.page_size
            * cache.layers[index].arena.num_key_value_heads
            * cache.layers[index].arena.head_dim
            * cache.layers[index].arena.key_cache.element_size()
            for index in plan.full_attention_layer_indices
        )
        self.assertEqual(
            fresh.audit["physical_document_block_copy_nbytes_including_padding"],
            expected_document_copy,
        )
        self.assertEqual(reuse.audit["physical_document_block_copy_nbytes_including_padding"], 0)
        self.assertEqual(conversion.max_request_forks, 4)

    def test_append_keeps_per_request_logical_payload_exact_and_storage_formula_closed(self):
        cache, plan, conversion = make_cache_and_plan(length=35, forks=4)
        fresh = build_resident_request_group(
            cache, plan, resident_count=4, policy=FRESH_CONTROL
        )
        reuse = build_resident_request_group(
            cache, plan, resident_count=4, policy=SHARED_REUSE
        )
        for request_index in range(4):
            generator = torch.Generator().manual_seed(8000 + request_index)
            for layer_index in plan.full_attention_layer_indices:
                key = torch.randn(1, 2, 7, 32, generator=generator)
                value = torch.randn(1, 2, 7, 32, generator=generator)
                fresh.requests[request_index].layers[layer_index].update(key, value)
                reuse.requests[request_index].layers[layer_index].update(key, value)
        parity = strict_group_logical_parity(fresh, reuse, plan.full_attention_layer_indices)
        self.assertTrue(parity["passed"])
        self.assertEqual(parity["row_count"], 40)
        fresh_storage = resident_storage_breakdown(cache, fresh, plan)
        reuse_storage = resident_storage_breakdown(cache, reuse, plan)
        fresh_totals = fresh_storage["totals"]
        reuse_totals = reuse_storage["totals"]
        self.assertEqual(
            fresh_totals["source_total_arena_allocated_nbytes"],
            conversion.allocated_block_pool_nbytes,
        )
        self.assertEqual(
            reuse_totals["source_total_arena_allocated_nbytes"],
            conversion.allocated_block_pool_nbytes,
        )
        self.assertEqual(
            fresh_totals["fresh_duplicate_document_allocated_nbytes"],
            fresh.audit["physical_document_block_copy_nbytes_including_padding"],
        )
        self.assertEqual(reuse_totals["fresh_duplicate_document_allocated_nbytes"], 0)
        self.assertEqual(
            fresh_totals["active_request_private_payload_nbytes"],
            reuse_totals["active_request_private_payload_nbytes"],
        )
        self.assertLessEqual(
            reuse_totals["active_request_private_payload_nbytes"],
            reuse_totals["active_request_private_allocated_page_nbytes"],
        )
        self.assertTrue(fresh_storage["active_private_payload_is_subset_not_additive"])

    def test_reuse_overlap_and_missing_strong_reference_fail_closed(self):
        cache, plan, _ = make_cache_and_plan(length=35, forks=4)
        reuse = build_resident_request_group(
            cache, plan, resident_count=4, policy=SHARED_REUSE
        )
        with self.assertRaisesRegex(QComemMultiForkError, "lost a strong"):
            validate_resident_group_ownership(
                cache,
                reuse.requests[:-1],
                plan,
                resident_count=4,
                policy=SHARED_REUSE,
            )
        layer_index = plan.full_attention_layer_indices[0]
        reuse.requests[1].layers[layer_index].sequence.reservations = (
            reuse.requests[0].layers[layer_index].sequence.reservations
        )
        with self.assertRaisesRegex(QComemMultiForkError, "reservations overlap"):
            validate_resident_group_ownership(
                cache,
                reuse.requests,
                plan,
                resident_count=4,
                policy=SHARED_REUSE,
            )

    def test_multifork_ledger_uses_one_kernel_and_exact_call_budget(self):
        cache, plan, _ = make_cache_and_plan(length=32, forks=2)
        group = build_resident_request_group(
            cache, plan, resident_count=2, policy=SHARED_REUSE
        )
        for request in group.requests:
            for layer_index in plan.full_attention_layer_indices:
                request.layers[layer_index].sequence.strict_mask_check = False
        kernel = ZeroKernel()
        ledgers = [
            MultiForkHitLedger(
                plan,
                request,
                request_index=request_index,
                resident_count=2,
                request_policy=SHARED_REUSE,
                expected_calls_per_layer=1,
                initial_query_tokens=1,
                kernel=kernel,
            )
            for request_index, request in enumerate(group.requests)
        ]
        self.assertTrue(all(ledger.kernel is kernel for ledger in ledgers))
        for request_index, (request, ledger) in enumerate(zip(group.requests, ledgers)):
            for layer_index in plan.full_attention_layer_indices:
                layer = request.layers[layer_index]
                key = torch.full((1, 2, 1, 32), float(request_index + 1))
                value = key.clone()
                layer.update(key, value)
                module = SimpleNamespace(
                    layer_idx=layer_index,
                    is_causal=True,
                    num_key_value_groups=8,
                    scaling=32**-0.5,
                )
                query = torch.randn(1, 16, 1, 32)
                position = torch.tensor([[32]], dtype=torch.long)
                output, _ = ledger.attention_forward(
                    module,
                    query,
                    layer.keys,
                    layer.values,
                    None,
                    position_ids=position,
                )
                self.assertEqual(tuple(output.shape), (1, 1, 16, 32))
            verified = ledger.verify_complete()
            self.assertEqual(verified["protocol"], MULTIFORK_PROTOCOL)
            self.assertEqual(verified["request_index"], request_index)
            self.assertEqual(verified["total_calls"], 10)

    def test_capacity_fit_locks_all_six_counts_and_linear_slope(self):
        rows = [
            {"resident_count": count, "physical_copy_nbytes": 1024 + count * 4096}
            for count in MULTIFORK_COUNTS
        ]
        fit = linear_capacity_fit(rows, "physical_copy_nbytes")
        self.assertEqual(fit["slope_nbytes_per_request"], 4096)
        self.assertEqual(fit["intercept_nbytes"], 1024)
        self.assertEqual(fit["r_squared"], 1.0)
        with self.assertRaisesRegex(QComemMultiForkError, "every N"):
            linear_capacity_fit(rows[:-1], "physical_copy_nbytes")
        bad = list(rows)
        bad[0] = {**bad[0], "resident_count": True}
        with self.assertRaisesRegex(QComemMultiForkError, "non-bool integer"):
            linear_capacity_fit(bad, "physical_copy_nbytes")

    def test_only_registered_resident_counts_are_accepted(self):
        cache, plan, _ = make_cache_and_plan(length=35, forks=3)
        with self.assertRaisesRegex(QComemMultiForkError, "unsupported"):
            build_resident_request_group(
                cache, plan, resident_count=3, policy=SHARED_REUSE
            )


if __name__ == "__main__":
    unittest.main()
