from __future__ import annotations

"""Multi-request resident controls for the Q16 vLLM paged-cache path.

This module is deliberately separate from the archived single-request fair-v2
runner.  One immutable document arena reserves private append pages for ``N``
simultaneously live requests.  The control arm instead materializes ``N``
independent request-owned document pools.  Both arms dispatch through the same
``unified_attention`` callable and retain every request object until the whole
round-robin generation has finished.
"""

import copy
import hashlib
import inspect
import math
from collections import Counter
from dataclasses import dataclass
from typing import Any, Iterable, Literal, Sequence

import torch

from qcomem_qwen35_native_cache import install_native_functional_linear_cache
from qcomem_qwen35_vllm_paged_integration import (
    POST_ROPE_POSITION_IDS_CONTRACT,
    register_qwen35_vllm_q16_backend,
    validate_qwen35_post_rope_position_ids,
)
from qcomem_vllm_paged_fair_control import FRESH_CONTROL, SHARED_REUSE
from qcomem_vllm_paged_kernel import (
    KERNEL_MODE,
    Q16KernelPagedDocumentLayer,
    Q16KernelPagedLayer,
    Q16KernelPagedTensorView,
    Q16PagedArena,
    _resolve_vllm_unified_attention,
    vllm_triton_q16_paged_attention_forward,
)


MULTIFORK_COUNTS = (1, 2, 4, 8, 16, 32)
MULTIFORK_PROTOCOL = "same-vllm-unified-attention-q16-multifork-resident-v1"
MULTIFORK_POLICIES = (FRESH_CONTROL, SHARED_REUSE)
PRODUCTION_MASK_CONTRACT = "prevalidated-no-padding-tail-causal"


class QComemMultiForkError(RuntimeError):
    """Raised when a resident multi-request invariant is violated."""


def _require(condition: bool, message: str) -> None:
    if not condition:
        raise QComemMultiForkError(message)


def _storage_key(tensor: torch.Tensor) -> tuple[str, int, int]:
    storage = tensor.untyped_storage()
    return str(tensor.device), storage.data_ptr(), storage.nbytes()


def _storage_inventory(*roots: Any) -> dict[tuple[str, int, int], int]:
    seen: set[int] = set()
    result: dict[tuple[str, int, int], int] = {}

    def visit(value: Any) -> None:
        identity = id(value)
        if identity in seen:
            return
        seen.add(identity)
        if isinstance(value, torch.Tensor):
            key = _storage_key(value)
            result[key] = key[2]
        elif isinstance(value, dict):
            for item in value.values():
                visit(item)
        elif isinstance(value, (list, tuple)):
            for item in value:
                visit(item)
        elif hasattr(value, "__dict__"):
            for item in vars(value).values():
                visit(item)

    for root in roots:
        visit(root)
    return result


def _inventory_nbytes(
    inventory: dict[tuple[str, int, int], int], *, accelerator_only: bool
) -> int:
    return sum(
        size
        for (device, _pointer, _size), size in inventory.items()
        if not accelerator_only or device.startswith("cuda")
    )


def _tensor_digest(tensor: torch.Tensor) -> str:
    raw = tensor.detach().contiguous().cpu().view(torch.uint8).numpy().tobytes()
    return hashlib.sha256(raw).hexdigest()


def build_deterministic_distinct_queries(
    base_query_ids: torch.Tensor,
    tokenizer: Any,
    *,
    count: int,
    query_tokens: int,
) -> tuple[list[torch.Tensor], dict[str, Any]]:
    """Create deterministic, pairwise-distinct token content for resident slots.

    A human-readable slot marker is appended before taking the final fixed-size
    tail.  The exact token digest is recorded and pairwise uniqueness is a hard
    gate; no random sampler or Python hash seed is involved.
    """

    _validate_count(count)
    _require(type(query_tokens) is int and query_tokens >= 8, "query_tokens must be >= 8")
    if base_query_ids.ndim == 2:
        _require(int(base_query_ids.shape[0]) == 1, "base query batch must be one")
        base = base_query_ids[0]
    else:
        _require(base_query_ids.ndim == 1, "base query must be rank one or [1,tokens]")
        base = base_query_ids
    _require(int(base.numel()) >= 1, "base query is empty")
    variants: list[torch.Tensor] = []
    rows: list[dict[str, Any]] = []
    for request_index in range(count):
        marker_text = f"\nResident request slot {request_index:02d}; continue independently.\n"
        marker_ids = tokenizer.encode(marker_text, add_special_tokens=False)
        _require(isinstance(marker_ids, (list, tuple)) and marker_ids, "tokenizer returned empty marker")
        marker = torch.tensor(marker_ids, dtype=base.dtype, device=base.device)
        combined = torch.cat((base, marker))
        if int(combined.numel()) >= query_tokens:
            variant = combined[-query_tokens:]
        else:
            repeats = math.ceil((query_tokens - int(marker.numel())) / int(base.numel()))
            prefix = base.repeat(repeats + 1)
            variant = torch.cat((prefix, marker))[-query_tokens:]
        variant = variant.contiguous().unsqueeze(0)
        digest = _tensor_digest(variant)
        variants.append(variant)
        rows.append(
            {
                "request_index": request_index,
                "query_token_ids_sha256": digest,
                "query_tokens": query_tokens,
                "marker_text": marker_text,
            }
        )
    digests = [row["query_token_ids_sha256"] for row in rows]
    _require(len(set(digests)) == count, "resident query token content is not pairwise distinct")
    return variants, {
        "deterministic": True,
        "pairwise_distinct": True,
        "count": count,
        "query_tokens": query_tokens,
        "rows": rows,
    }


def build_pg19_train_query_bank(
    records: Sequence[dict[str, Any]],
    tokenizer: Any,
    window: Any,
    *,
    document_tokens: int,
    query_tokens: int,
    count: int,
    query_stride: int,
) -> tuple[list[torch.Tensor], dict[str, Any]]:
    """Freeze non-overlapping raw-token queries from the document's train book.

    Query chunks begin after the selected document and the calibration
    builder's adjacent query.  They are therefore outside the 4095-token
    document while remaining in the exact same PG-19 train object.  No
    synthetic marker or evaluation text is introduced.
    """

    _validate_count(count)
    _require(type(document_tokens) is int and document_tokens > 0, "document_tokens must be positive")
    _require(type(query_tokens) is int and query_tokens > 0, "query_tokens must be positive")
    _require(type(query_stride) is int and query_stride >= query_tokens, "query stride must prevent overlap")
    source_object = str(getattr(window, "source_object", ""))
    start_token = getattr(window, "start_token", None)
    _require(source_object and type(start_token) is int and start_token >= 0, "window provenance is incomplete")
    matches = [record for record in records if str(record.get("_source_object")) == source_object]
    _require(len(matches) == 1, "query bank source object is not unique in PG19 records")
    record = matches[0]
    text = record.get("text")
    _require(isinstance(text, str) and text, "query bank source has no raw text")
    document_start = start_token
    document_end = document_start + document_tokens
    bank_start = document_end + query_tokens
    offsets = [bank_start + index * query_stride for index in range(count)]
    required_tokens = offsets[-1] + query_tokens
    guarded_tokens = required_tokens + 64
    character_limit = min(len(text), max(guarded_tokens * 6, 8192))
    while True:
        ids = tokenizer.encode(text[:character_limit], add_special_tokens=False)
        if len(ids) >= guarded_tokens or character_limit == len(text):
            break
        character_limit = min(len(text), character_limit * 2)
    _require(len(ids) >= required_tokens, "PG19 train book is too short for the frozen query bank")
    queries = [
        torch.tensor(ids[offset : offset + query_tokens], dtype=torch.long).unsqueeze(0)
        for offset in offsets
    ]
    rows = [
        {
            "request_index": request_index,
            "source_token_offset": offsets[request_index],
            "query_tokens": query_tokens,
            "query_token_ids_sha256": _tensor_digest(query),
        }
        for request_index, query in enumerate(queries)
    ]
    digests = [row["query_token_ids_sha256"] for row in rows]
    _require(len(set(digests)) == count, "PG19 raw query chunks are not pairwise distinct")
    for left, offset in enumerate(offsets):
        _require(offset >= document_end, "query bank overlaps the document window")
        for right in range(left + 1, len(offsets)):
            _require(
                offset + query_tokens <= offsets[right]
                or offsets[right] + query_tokens <= offset,
                "query bank chunks overlap",
            )
    bank_digest = hashlib.sha256()
    bank_digest.update(source_object.encode())
    bank_digest.update(f"{document_start}:{document_end}:{query_tokens}:{query_stride}\n".encode())
    for row, query in zip(rows, queries):
        bank_digest.update(f"{row['request_index']}:{row['source_token_offset']}\0".encode())
        bank_digest.update(query.numpy().tobytes())
    return queries, {
        "source_role": "same-pg19-train-book-raw-nonoverlapping-query-chunks",
        "synthetic_markers_used": False,
        "source_object": source_object,
        "source_id": str(getattr(window, "source_id", record.get("id", ""))),
        "document_start_token": document_start,
        "document_end_token_exclusive": document_end,
        "query_bank_start_token": bank_start,
        "query_stride_tokens": query_stride,
        "query_tokens": query_tokens,
        "count": count,
        "pairwise_nonoverlapping": True,
        "pairwise_distinct": True,
        "rows": rows,
        "query_bank_sha256": bank_digest.hexdigest(),
    }


def _validate_count(count: int) -> None:
    _require(type(count) is int and count in MULTIFORK_COUNTS, "unsupported resident request count")


def _seed_tensor_memo(value: Any, memo: dict[int, Any], seen: set[int]) -> None:
    identity = id(value)
    if identity in seen:
        return
    seen.add(identity)
    if isinstance(value, torch.Tensor):
        memo[identity] = value
    elif isinstance(value, dict):
        for item in value.values():
            _seed_tensor_memo(item, memo, seen)
    elif isinstance(value, (list, tuple)):
        for item in value:
            _seed_tensor_memo(item, memo, seen)
    elif hasattr(value, "__dict__"):
        for item in vars(value).values():
            _seed_tensor_memo(item, memo, seen)


@dataclass(frozen=True)
class ResidentRequestGroup:
    policy: str
    resident_count: int
    requests: tuple[Any, ...]
    audit: dict[str, Any]


def _materialize_fresh_layer(
    document: Q16KernelPagedDocumentLayer,
) -> tuple[Q16KernelPagedLayer, dict[str, int | bool]]:
    source = document.arena
    document_physical = source.batch_size * source.document_blocks_per_sequence
    private_physical = source.batch_size * source.private_blocks_per_sequence
    physical_blocks = document_physical + private_physical
    shape = (
        physical_blocks,
        source.page_size,
        source.num_key_value_heads,
        source.head_dim,
    )
    key_cache = torch.empty(shape, dtype=source.key_cache.dtype, device=source.key_cache.device)
    value_cache = torch.empty_like(key_cache)
    key_cache[:document_physical].copy_(source.key_cache[:document_physical])
    value_cache[:document_physical].copy_(source.value_cache[:document_physical])
    document_table = source.document_block_table.clone()
    reservations = torch.arange(
        document_physical,
        physical_blocks,
        dtype=torch.int64,
        device="cpu",
    ).reshape(1, source.batch_size, source.private_blocks_per_sequence)
    arena = Q16PagedArena(
        key_cache,
        value_cache,
        document_table,
        document_length=source.document_length,
        max_append_tokens=source.max_append_tokens,
        max_forks=1,
        private_block_reservations=reservations,
    )
    _require(not (arena.storage_keys & source.storage_keys), "fresh pool shares source storage")
    document_copy = (
        2
        * document_physical
        * source.page_size
        * source.num_key_value_heads
        * source.head_dim
        * source.key_cache.element_size()
    )
    return Q16KernelPagedLayer(
        arena.fork(strict_mask_check=document.strict_mask_check)
    ), {
        "document_block_copy_nbytes_including_padding": document_copy,
        "document_payload_nbytes": source.audit.document_payload_nbytes,
        "copied_padding_nbytes": document_copy - source.audit.document_payload_nbytes,
        "allocated_request_pool_nbytes": arena.allocated_pool_nbytes,
        "source_storage_shared": False,
    }


def _fresh_request(cache: Any, plan: Any) -> tuple[Any, dict[str, Any]]:
    memo: dict[int, Any] = {}
    for index in plan.full_attention_layer_indices:
        layer = cache.layers[index]
        _require(isinstance(layer, Q16KernelPagedDocumentLayer), f"source layer {index} is not paged")
        memo[id(layer)] = layer
    _seed_tensor_memo(cache, memo, set())
    request = copy.deepcopy(cache, memo)
    rows = []
    copied = allocated = payload = 0
    for index in plan.full_attention_layer_indices:
        target, row = _materialize_fresh_layer(cache.layers[index])
        request.layers[index] = target
        copied += int(row["document_block_copy_nbytes_including_padding"])
        allocated += int(row["allocated_request_pool_nbytes"])
        payload += int(row["document_payload_nbytes"])
        rows.append({"layer_idx": int(index), **row})
    install = install_native_functional_linear_cache(request, plan.gdn)
    _require(
        tuple(install.linear_layer_indices) == tuple(plan.linear_layer_indices),
        "fresh request missed functional GDN layers",
    )
    return request, {
        "document_block_copy_nbytes_including_padding": copied,
        "allocated_request_pool_nbytes": allocated,
        "document_payload_nbytes": payload,
        "source_document_storage_shared": False,
        "layers": rows,
    }


def _reuse_request(cache: Any, plan: Any) -> tuple[Any, dict[str, Any]]:
    memo: dict[int, Any] = {}
    for index in plan.full_attention_layer_indices:
        layer = cache.layers[index]
        _require(isinstance(layer, Q16KernelPagedDocumentLayer), f"source layer {index} is not paged")
        memo[id(layer)] = layer
    _seed_tensor_memo(cache, memo, set())
    request = copy.deepcopy(cache, memo)
    for index in plan.full_attention_layer_indices:
        source = cache.layers[index]
        target = source.fork()
        _require(target.sequence.arena is source.arena, "reuse request did not share source arena")
        request.layers[index] = target
    install = install_native_functional_linear_cache(request, plan.gdn)
    _require(
        tuple(install.linear_layer_indices) == tuple(plan.linear_layer_indices),
        "reuse request missed functional GDN layers",
    )
    return request, {
        "document_block_copy_nbytes_including_padding": 0,
        "allocated_request_pool_nbytes": 0,
        "source_document_storage_shared": True,
    }


def build_resident_request_group(
    cache: Any,
    plan: Any,
    *,
    resident_count: int,
    policy: Literal[
        "vllm-q16-fresh-full-copy-control",
        "vllm-q16-shared-document-reuse",
    ],
) -> ResidentRequestGroup:
    """Create all ``N`` requests before returning; none is released in-loop."""

    _validate_count(resident_count)
    _require(policy in MULTIFORK_POLICIES, "unknown multi-fork policy")
    for index in plan.full_attention_layer_indices:
        source = cache.layers[index]
        _require(isinstance(source, Q16KernelPagedDocumentLayer), "source is not Q16 paged")
        _require(source.arena.max_forks == resident_count, "source max_forks differs from N")
        _require(source.arena._fork_cursor == 0, "source arena was already forked")
    requests: list[Any] = []
    rows = []
    for request_index in range(resident_count):
        request, row = (
            _fresh_request(cache, plan)
            if policy == FRESH_CONTROL
            else _reuse_request(cache, plan)
        )
        requests.append(request)
        rows.append({"request_index": request_index, **row})
    _require(len({id(request) for request in requests}) == resident_count, "request objects alias")
    ownership = validate_resident_group_ownership(
        cache, requests, plan, resident_count=resident_count, policy=policy
    )
    return ResidentRequestGroup(
        policy=policy,
        resident_count=resident_count,
        requests=tuple(requests),
        audit={
            "protocol": MULTIFORK_PROTOCOL,
            "policy": policy,
            "resident_count": resident_count,
            "all_requests_materialized_before_measurement": True,
            "strong_reference_count": len(requests),
            "rows": rows,
            "ownership": ownership,
            "physical_document_block_copy_nbytes_including_padding": sum(
                int(row["document_block_copy_nbytes_including_padding"])
                for row in rows
            ),
            "allocated_fresh_request_pool_nbytes": sum(
                int(row["allocated_request_pool_nbytes"]) for row in rows
            ),
        },
    )


def validate_resident_group_ownership(
    cache: Any,
    requests: Sequence[Any],
    plan: Any,
    *,
    resident_count: int,
    policy: str,
) -> dict[str, Any]:
    _require(len(requests) == resident_count, "resident group lost a strong request reference")
    sequence_ids: set[int] = set()
    arena_storage_sets: list[frozenset[tuple[str, int, int]]] = []
    reservation_id_sets_by_layer: dict[int, list[set[int]]] = {
        int(index): [] for index in plan.full_attention_layer_indices
    }
    for request in requests:
        for index in plan.full_attention_layer_indices:
            source = cache.layers[index].arena
            layer = request.layers[index]
            _require(isinstance(layer, Q16KernelPagedLayer), "resident layer is not writable paged")
            sequence = layer.sequence
            sequence_ids.add(id(sequence))
            if policy == SHARED_REUSE:
                _require(sequence.arena is source, "reuse request uses a different source arena")
            else:
                _require(sequence.arena is not source, "fresh request shares the source arena")
            reservation_id_sets_by_layer[int(index)].append(
                {int(value) for value in sequence.reservations.reshape(-1).tolist()}
            )
        arena_storage_sets.append(
            frozenset().union(
                *(request.layers[index].sequence.arena.storage_keys for index in plan.full_attention_layer_indices)
            )
        )
    expected_sequences = resident_count * len(tuple(plan.full_attention_layer_indices))
    _require(len(sequence_ids) == expected_sequences, "request sequences are not pairwise distinct")
    if policy == SHARED_REUSE:
        # Physical ids are comparable only inside the one shared arena.  Each
        # fresh arena has its own local id namespace and is instead proven
        # disjoint by its K/V storage identity below.
        for index, id_sets in reservation_id_sets_by_layer.items():
            for left in range(len(id_sets)):
                for right in range(left + 1, len(id_sets)):
                    _require(not (id_sets[left] & id_sets[right]), f"layer {index} private reservations overlap")
    if policy == FRESH_CONTROL:
        for left in range(len(arena_storage_sets)):
            for right in range(left + 1, len(arena_storage_sets)):
                _require(
                    not (arena_storage_sets[left] & arena_storage_sets[right]),
                    "fresh request pools share storage",
                )
    else:
        _require(len(set(arena_storage_sets)) == 1, "reuse requests do not share one source pool")
    return {
        "passed": True,
        "resident_count": resident_count,
        "request_object_ids_pairwise_distinct": True,
        "request_sequence_ids_pairwise_distinct": True,
        "private_physical_reservation_ids_pairwise_disjoint": policy == SHARED_REUSE,
        "fresh_private_id_namespace_is_per_arena": policy == FRESH_CONTROL,
        "reuse_requests_share_source_arena": policy == SHARED_REUSE,
        "fresh_request_arena_storages_pairwise_disjoint": policy == FRESH_CONTROL,
        "all_requests_strongly_referenced": True,
    }


def resident_storage_breakdown(
    persistent: Any,
    group: ResidentRequestGroup,
    plan: Any,
) -> dict[str, Any]:
    """Split common source capacity, N fresh pools and active private pages."""

    n = group.resident_count
    policy = group.policy
    _validate_count(n)
    _require(len(group.requests) == n, "storage audit requires all resident requests alive")
    rows: list[dict[str, Any]] = []
    totals: Counter[str] = Counter()
    for index in plan.full_attention_layer_indices:
        source = persistent.layers[index].arena
        _require(source.max_forks == n, "source private reservation multiplier differs from N")
        block_bytes = (
            2
            * source.page_size
            * source.num_key_value_heads
            * source.head_dim
            * source.key_cache.element_size()
        )
        document_allocated = source.batch_size * source.document_blocks_per_sequence * block_bytes
        source_private = n * source.batch_size * source.private_blocks_per_sequence * block_bytes
        _require(
            source.allocated_pool_nbytes == document_allocated + source_private,
            "source arena storage formula drift",
        )
        fresh_document = n * document_allocated if policy == FRESH_CONTROL else 0
        fresh_padding = (
            n * (document_allocated - source.audit.document_payload_nbytes)
            if policy == FRESH_CONTROL
            else 0
        )
        one_private = source.batch_size * source.private_blocks_per_sequence * block_bytes
        fresh_private = n * one_private if policy == FRESH_CONTROL else 0
        active_payload = active_pages = active_blocks = 0
        request_table = 0
        fresh_document_table = 0
        detached_tail_total = appended_total = 0
        partial_tail_copy = 0
        for request in group.requests:
            sequence = request.layers[index].sequence
            appended = int(sequence.appended_tokens)
            tail = source.document_length % source.page_size if appended > 0 else 0
            private_tokens = tail + appended
            blocks = math.ceil(private_tokens / source.page_size) if private_tokens else 0
            active_payload += (
                2
                * source.batch_size
                * private_tokens
                * source.num_key_value_heads
                * source.head_dim
                * source.key_cache.element_size()
            )
            active_pages += blocks * source.batch_size * block_bytes
            active_blocks += blocks * source.batch_size
            detached_tail_total += tail
            appended_total += appended
            partial_tail_copy += int(sequence.partial_tail_staging_copy_nbytes)
            request_table += sequence.block_table.untyped_storage().nbytes()
            if policy == FRESH_CONTROL:
                fresh_document_table += (
                    sequence.arena.document_block_table.untyped_storage().nbytes()
                )
        reservation_for_requests = n * one_private
        _require(active_payload <= active_pages <= reservation_for_requests, "active pages exceed reservation")
        row = {
            "layer_idx": int(index),
            "resident_count": n,
            "block_bytes": block_bytes,
            "valid_document_payload_nbytes": source.audit.document_payload_nbytes,
            "source_document_allocated_nbytes": document_allocated,
            "source_document_padding_nbytes": document_allocated - source.audit.document_payload_nbytes,
            "source_private_reservation_nbytes": source_private,
            "source_total_arena_allocated_nbytes": document_allocated + source_private,
            "fresh_duplicate_document_allocated_nbytes": fresh_document,
            "fresh_duplicate_document_padding_nbytes": fresh_padding,
            "fresh_duplicate_private_reservation_nbytes": fresh_private,
            "active_request_private_payload_nbytes": active_payload,
            "active_request_private_allocated_page_nbytes": active_pages,
            "active_request_private_blocks": active_blocks,
            "request_private_reserved_unused_nbytes": reservation_for_requests - active_pages,
            "active_request_appended_tokens_sum": appended_total,
            "active_request_detached_tail_tokens_sum": detached_tail_total,
            "partial_tail_staging_copy_nbytes": partial_tail_copy,
            "request_block_table_accelerator_nbytes": request_table,
            "source_document_table_accelerator_nbytes": source.document_block_table.untyped_storage().nbytes(),
            "fresh_document_table_accelerator_nbytes": fresh_document_table,
            "source_cpu_reservation_metadata_nbytes": source.private_block_reservations.untyped_storage().nbytes(),
            "fresh_cpu_reservation_metadata_nbytes": (
                sum(
                    request.layers[index].sequence.arena.private_block_reservations.untyped_storage().nbytes()
                    for request in group.requests
                )
                if policy == FRESH_CONTROL
                else 0
            ),
            "physical_document_block_copy_nbytes_including_padding": fresh_document,
        }
        for key, value in row.items():
            if key.endswith("_nbytes") or key in (
                "active_request_private_blocks",
                "active_request_appended_tokens_sum",
                "active_request_detached_tail_tokens_sum",
                "physical_document_block_copy_nbytes_including_padding",
            ):
                totals[key] += int(value)
        rows.append(row)
    persistent_inventory = _storage_inventory(persistent)
    request_inventory = _storage_inventory(*group.requests)
    combined = dict(persistent_inventory)
    combined.update(request_inventory)
    return {
        "protocol": MULTIFORK_PROTOCOL,
        "policy": policy,
        "resident_count": n,
        "simultaneous_lifetime": True,
        "full_attention_layer_count": len(rows),
        "source_private_reservation_is_common_pack_capacity": True,
        "active_private_payload_is_subset_not_additive": True,
        "fresh_duplicate_pool_is_separate_from_source": policy == FRESH_CONTROL,
        "totals": dict(totals),
        "layers": rows,
        "unique_storage": {
            "persistent_total_nbytes": _inventory_nbytes(persistent_inventory, accelerator_only=False),
            "persistent_accelerator_nbytes": _inventory_nbytes(persistent_inventory, accelerator_only=True),
            "requests_total_nbytes": _inventory_nbytes(request_inventory, accelerator_only=False),
            "requests_accelerator_nbytes": _inventory_nbytes(request_inventory, accelerator_only=True),
            "combined_unique_total_nbytes": _inventory_nbytes(combined, accelerator_only=False),
            "combined_unique_accelerator_nbytes": _inventory_nbytes(combined, accelerator_only=True),
        },
    }


def strict_group_logical_parity(
    fresh: ResidentRequestGroup,
    reuse: ResidentRequestGroup,
    layer_indices: Iterable[int],
) -> dict[str, Any]:
    from qcomem_vllm_paged_fair_control import strict_logical_layout_parity

    _require(fresh.resident_count == reuse.resident_count, "resident counts differ")
    rows = []
    for request_index in range(fresh.resident_count):
        for layer_index in layer_indices:
            parity = strict_logical_layout_parity(
                fresh.requests[request_index].layers[layer_index].sequence,
                reuse.requests[request_index].layers[layer_index].sequence,
            )
            rows.append(
                {"request_index": request_index, "layer_idx": int(layer_index), **parity}
            )
    return {
        "passed": True,
        "resident_count": fresh.resident_count,
        "row_count": len(rows),
        "rows": rows,
    }


class MultiForkHitLedger:
    """Per-request same-kernel ledger carrying multi-resident identity."""

    def __init__(
        self,
        plan: Any,
        request: Any,
        *,
        request_index: int,
        resident_count: int,
        request_policy: str,
        expected_calls_per_layer: int,
        initial_query_tokens: int,
        kernel: Any | None = None,
    ) -> None:
        _validate_count(resident_count)
        _require(0 <= request_index < resident_count, "request index is outside resident group")
        _require(request_policy in MULTIFORK_POLICIES, "unknown ledger policy")
        _require(type(expected_calls_per_layer) is int and expected_calls_per_layer > 0, "call budget must be positive")
        _require(type(initial_query_tokens) is int and initial_query_tokens > 0, "initial query tokens must be positive")
        self.indices = tuple(plan.full_attention_layer_indices)
        _require(len(self.indices) == 10, "formal Qwen3.5 run requires ten full layers")
        self.request_index = request_index
        self.resident_count = resident_count
        self.request_policy = request_policy
        self.expected_calls_per_layer = expected_calls_per_layer
        self.initial_query_tokens = initial_query_tokens
        self.kernel = _resolve_vllm_unified_attention() if kernel is None else kernel
        _require(callable(self.kernel), "unified_attention kernel is not callable")
        try:
            signature = str(inspect.signature(self.kernel))
        except (TypeError, ValueError):
            signature = "<signature-unavailable>"
        self.kernel_identity = {
            "callable_id": id(self.kernel),
            "module": str(getattr(self.kernel, "__module__", type(self.kernel).__module__)),
            "qualname": str(getattr(self.kernel, "__qualname__", type(self.kernel).__qualname__)),
            "signature": signature,
        }
        self.mask_contract = PRODUCTION_MASK_CONTRACT
        self.arena_ids = {}
        self.last_lengths = {}
        for index in self.indices:
            layer = request.layers[index]
            _require(isinstance(layer, Q16KernelPagedLayer), f"request layer {index} is not paged")
            self.arena_ids[index] = id(layer.sequence.arena)
            self.last_lengths[index] = int(layer.sequence.sequence_length)
        self.counts: Counter[int] = Counter()
        self.calls: list[dict[str, Any]] = []

    def attention_forward(
        self,
        module: torch.nn.Module,
        query: torch.Tensor,
        key: Q16KernelPagedTensorView,
        value: Q16KernelPagedTensorView,
        attention_mask: torch.Tensor | dict[str, torch.Tensor] | None,
        *args: Any,
        **kwargs: Any,
    ) -> tuple[torch.Tensor, None]:
        index = getattr(module, "layer_idx", None)
        _require(index in self.arena_ids, f"unexpected full-attention layer {index}")
        _require(isinstance(key, Q16KernelPagedTensorView) and isinstance(value, Q16KernelPagedTensorView), "dense fallback")
        sequence = key.sequence
        _require(value.sequence is sequence, "K/V sequence differs")
        _require(id(sequence.arena) == self.arena_ids[index], "request arena changed")
        _require(self.counts[index] < self.expected_calls_per_layer, "call budget exceeded")
        query_length = int(query.shape[-2])
        delta = int(sequence.sequence_length) - self.last_lengths[index]
        _require(delta == query_length, "current append delta differs from query tokens")
        self.last_lengths[index] = int(sequence.sequence_length)
        _require(attention_mask is None and not sequence.strict_mask_check, "production path materialized a mask")
        position_ids = kwargs.pop("position_ids", None)
        position = validate_qwen35_post_rope_position_ids(
            position_ids,
            query=query,
            total_length=int(sequence.sequence_length),
            strict_tail_values=False,
        )
        audit: dict[str, Any] = {}
        result = vllm_triton_q16_paged_attention_forward(
            module,
            query,
            key,
            value,
            attention_mask,
            *args,
            audit=audit,
            _kernel=self.kernel,
            **kwargs,
        )
        self.counts[index] += 1
        self.calls.append(
            {
                "request_index": self.request_index,
                "resident_count": self.resident_count,
                "layer_idx": int(index),
                "request_policy": self.request_policy,
                "protocol": MULTIFORK_PROTOCOL,
                "kernel_identity": dict(self.kernel_identity),
                "current_append_delta_tokens": delta,
                "mask_contract": self.mask_contract,
                "materialized_attention_mask_nbytes": 0,
                "mask_validation_host_syncs": 0,
                **audit,
                **position,
            }
        )
        return result

    def verify_complete(self) -> dict[str, Any]:
        expected = {index: self.expected_calls_per_layer for index in self.indices}
        actual = {index: self.counts[index] for index in self.indices}
        _require(actual == expected, "multi-fork same-kernel intercept incomplete")
        expected_layer_order = list(self.indices) * self.expected_calls_per_layer
        _require(
            [int(row["layer_idx"]) for row in self.calls] == expected_layer_order,
            "multi-fork layer/round call order drift",
        )
        expected_deltas = [self.initial_query_tokens] + [1] * (
            self.expected_calls_per_layer - 1
        )
        actual_deltas = [
            [
                int(row["current_append_delta_tokens"])
                for row in self.calls[
                    round_index * len(self.indices) : (round_index + 1) * len(self.indices)
                ]
            ]
            for round_index in range(self.expected_calls_per_layer)
        ]
        _require(
            actual_deltas
            == [[delta] * len(self.indices) for delta in expected_deltas],
            "multi-fork round append-delta schedule drift",
        )
        _require(
            all(row.get("kernel_identity") == self.kernel_identity for row in self.calls),
            "multi-fork per-call kernel identity drift",
        )
        return {
            "verified": True,
            "protocol": MULTIFORK_PROTOCOL,
            "request_index": self.request_index,
            "resident_count": self.resident_count,
            "request_policy": self.request_policy,
            "kernel_mode": KERNEL_MODE,
            "kernel_identity": dict(self.kernel_identity),
            "same_unified_attention_kernel": True,
            "counts": actual,
            "total_calls": sum(actual.values()),
            "round_major_request_local_layer_order_verified": True,
            "initial_query_tokens": self.initial_query_tokens,
            "dense_fallback_calls": 0,
            "full_kv_concatenations": 0,
            "mask_contract": self.mask_contract,
            "position_ids_contract": POST_ROPE_POSITION_IDS_CONTRACT,
            "calls": tuple(self.calls),
        }


def register_multifork_backend(ledger: MultiForkHitLedger) -> str:
    return register_qwen35_vllm_q16_backend(ledger).name


def linear_capacity_fit(rows: Sequence[dict[str, Any]], field: str) -> dict[str, Any]:
    """Fit one auditable bytes-vs-N line without external dependencies."""

    _require(len(rows) == len(MULTIFORK_COUNTS), "capacity curve must contain every N")
    raw_counts = [row.get("resident_count") for row in rows]
    _require(
        all(type(value) is int for value in raw_counts),
        "capacity curve resident_count must be a present non-bool integer",
    )
    xs = list(raw_counts)
    _require(tuple(xs) == MULTIFORK_COUNTS, "capacity curve N order drift")
    raw_values = [row.get(field) for row in rows]
    _require(
        all(type(value) is int and value >= 0 for value in raw_values),
        "capacity fit bytes must be present non-bool integers >= 0",
    )
    ys = [float(value) for value in raw_values]
    x_mean = sum(xs) / len(xs)
    y_mean = sum(ys) / len(ys)
    denominator = sum((x - x_mean) ** 2 for x in xs)
    _require(denominator > 0, "capacity fit has zero denominator")
    slope = sum((x - x_mean) * (y - y_mean) for x, y in zip(xs, ys)) / denominator
    intercept = y_mean - slope * x_mean
    predictions = [intercept + slope * x for x in xs]
    residual = sum((y - prediction) ** 2 for y, prediction in zip(ys, predictions))
    total = sum((y - y_mean) ** 2 for y in ys)
    r_squared = 1.0 if total == 0 and residual == 0 else 1.0 - residual / total
    _require(
        all(math.isfinite(value) for value in (slope, intercept, r_squared)),
        "capacity fit produced a non-finite result",
    )
    return {
        "field": field,
        "sample_count": len(rows),
        "resident_counts": xs,
        "values_nbytes": ys,
        "slope_nbytes_per_request": slope,
        "intercept_nbytes": intercept,
        "r_squared": r_squared,
    }


__all__ = [
    "MULTIFORK_COUNTS",
    "MULTIFORK_POLICIES",
    "MULTIFORK_PROTOCOL",
    "MultiForkHitLedger",
    "QComemMultiForkError",
    "ResidentRequestGroup",
    "build_deterministic_distinct_queries",
    "build_pg19_train_query_bank",
    "build_resident_request_group",
    "linear_capacity_fit",
    "register_multifork_backend",
    "resident_storage_breakdown",
    "strict_group_logical_parity",
    "validate_resident_group_ownership",
]
