#!/usr/bin/env python3
"""Fail-closed numeric and scope audit for the ForkAudit manuscript.

This script does not reinterpret GPU outputs.  It reconstructs the headline
quantities from every frozen raw shard, checks them against the aggregate and
derived artifacts, and verifies that the English manuscript contains the exact
bounded numbers, measurement windows, and disclaimers.
"""

from __future__ import annotations

import hashlib
import json
import math
import statistics
from pathlib import Path


ROOT = Path(__file__).resolve().parents[2]
PAPER = Path(__file__).resolve().parents[1]
RAW = ROOT / "results/gpu-qwen35-vllm-paged-multifork-resident-20260814a"
SUMMARY = RAW / "multifork-resident-summary.json"
SHARDS = RAW / "resident-shards"
MANUSCRIPT = PAPER / "main.tex"
OUTPUT = PAPER / "generated/manuscript_evidence_audit.json"
ANONYMOUS = PAPER / "supplement_anonymous/raw_primary"
ANONYMOUS_SUMMARY = ANONYMOUS / "multifork-resident-summary.json"
ANONYMOUS_SHARDS = ANONYMOUS / "resident-shards"
ANONYMOUS_MANIFEST = PAPER / "supplement_anonymous/ANONYMOUS_MANIFEST.sha256"
ARTIFACT_METRICS = PAPER / "generated/artifact_metrics.json"


def require(condition: bool, message: str) -> None:
    if not condition:
        raise RuntimeError(message)


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for block in iter(lambda: handle.read(1 << 20), b""):
            digest.update(block)
    return digest.hexdigest()


def close(left: float, right: float, tolerance: float = 1e-12) -> bool:
    return math.isclose(left, right, rel_tol=tolerance, abs_tol=tolerance)


def main() -> None:
    summary = json.loads(SUMMARY.read_text())
    manuscript = MANUSCRIPT.read_text()
    normalized_manuscript = " ".join(manuscript.split())
    rows = summary["capacity_matrix"]
    require(summary["passed"] is True, "primary aggregate is not passed")
    require(summary["resident_counts"] == [1, 2, 4, 8, 16, 32], "N grid drift")
    require(len(rows) == 6, "capacity row count drift")
    require(summary["rank_count"] == summary["world_size"] == 8, "rank count drift")
    require(summary["same_kernel_full_logit_token_logical_kv_gdn_exact_fraction"] == 1.0,
            "primary exactness fraction drift")
    require(summary["cross_n_prefix_isolation_exact"] is True, "cross-N gate drift")
    require(summary["pg19_train_only"] is True, "PG-19 train-only gate drift")
    require(not summary["longbench_consumed"], "LongBench unexpectedly consumed")
    require(not summary["test_v2_consumed"], "test-v2 unexpectedly consumed")

    n32 = next(row for row in rows if row["resident_count"] == 32)
    summary_rows_by_n = {int(row["resident_count"]): row for row in rows}
    fresh_pool = (
        n32["fresh"]["source_document_allocated_nbytes"]
        + n32["fresh"]["source_private_reservation_nbytes"]
        + n32["fresh"]["fresh_duplicate_document_allocated_nbytes"]
        + n32["fresh"]["fresh_duplicate_private_reservation_nbytes"]
    )
    reuse_pool = (
        n32["reuse"]["source_document_allocated_nbytes"]
        + n32["reuse"]["source_private_reservation_nbytes"]
    )
    require(fresh_pool == 2960 * 2**20, "fresh N=32 pool drift")
    require(reuse_pool == 240 * 2**20, "reuse N=32 pool drift")
    counterfactual_fresh_pool = 85 * 32 * 2**20
    counterfactual_difference = counterfactual_fresh_pool - reuse_pool
    require(counterfactual_difference == 2480 * 2**20, "counterfactual N=32 difference drift")

    shard_paths = sorted(SHARDS.glob("multifork-resident-shard-*.json"))
    require(len(shard_paths) == 8, "raw shard count drift")
    paired_requests = paired_generation_steps = logical_kv_pairs = gdn_pairs = fused_calls = 0
    unique_query_hashes: set[str] = set()
    phase_windows: dict[int, dict[str, dict[str, list[int]]]] = {
        n: {
            arm: {"post_pack_production": [], "full_recorded_lifecycle": []}
            for arm in ("fresh", "reuse")
        }
        for n in summary["resident_counts"]
    }
    for path in shard_paths:
        shard = json.loads(path.read_text())
        query_rows = shard["query_bank"]["rows"]
        require(len(query_rows) == 32, f"query bank size drift: {path.name}")
        unique_query_hashes.update(row["query_token_ids_sha256"] for row in query_rows)
        for row in shard["rows"]:
            n = row["resident_count"]
            require(n in phase_windows, f"unexpected resident count in {path.name}: {n}")
            for arm in ("fresh", "reuse"):
                arm_row = row[arm]
                setup_peak = arm_row["resident_setup"]["allocator_after"]["peak_allocated_bytes"]
                generation_peak = arm_row["generation"][
                    "production_allocator_before_exactness"
                ]["peak_allocated_bytes"]
                post_pack_peak = max(setup_peak, generation_peak)
                require(
                    post_pack_peak
                    == arm_row["generation_only"]["production_absolute_peak_allocated_bytes"],
                    f"{path.name} N={n} {arm} generation-only production peak drift",
                )
                require(
                    post_pack_peak
                    == arm_row["setup_plus_generation"]["combined_absolute_peak_allocated_bytes"],
                    f"{path.name} N={n} {arm} legacy combined peak drift",
                )
                lifecycle_peak = max(
                    arm_row["common_document_prefill"]["allocator_after"]["peak_allocated_bytes"],
                    arm_row["common_q16_pack"]["allocator_after"]["peak_allocated_bytes"],
                    setup_peak,
                    generation_peak,
                )
                phase_windows[n][arm]["post_pack_production"].append(post_pack_peak)
                phase_windows[n][arm]["full_recorded_lifecycle"].append(lifecycle_peak)
            paired_requests += n
            paired_generation_steps += n * 8
            logical_kv_pairs += n * 10
            gdn_pairs += n
            for arm in (row["fresh"], row["reuse"]):
                fused_calls += sum(item["total_calls"] for item in arm["intercepts"])
    require(len(unique_query_hashes) == 256, "unique query count drift")
    require(paired_requests == 504, "paired request count drift")
    require(paired_generation_steps == 4032, "paired generation-step count drift")
    arm_specific_model_steps = 2 * paired_generation_steps
    require(arm_specific_model_steps == 8064, "arm-specific model-step count drift")
    require(logical_kv_pairs == 5040, "logical-KV pair count drift")
    require(gdn_pairs == 504, "GDN pair count drift")
    require(fused_calls == 80640, "fused-call count drift")
    allocator_windows_by_n: list[dict[str, int | bool]] = []
    for n in summary["resident_counts"]:
        replayed: dict[str, dict[str, int]] = {}
        for arm in ("fresh", "reuse"):
            replayed[arm] = {}
            for window in ("post_pack_production", "full_recorded_lifecycle"):
                values = phase_windows[n][arm][window]
                require(len(values) == 8, f"N={n} {arm} {window} rank coverage drift")
                require(len(set(values)) == 1, f"N={n} {arm} {window} differs across ranks")
                replayed[arm][window] = int(statistics.median(values))
        summary_row = summary_rows_by_n[n]
        require(
            replayed["fresh"]["post_pack_production"]
            == summary_row["fresh"]["production_absolute_peak_allocated_median_bytes"],
            f"N={n} fresh summary production peak drift",
        )
        require(
            replayed["reuse"]["post_pack_production"]
            == summary_row["reuse"]["production_absolute_peak_allocated_median_bytes"],
            f"N={n} reuse summary production peak drift",
        )
        allocator_windows_by_n.append(
            {
                "resident_count": n,
                "fresh_post_pack_production_peak_bytes": replayed["fresh"]["post_pack_production"],
                "reuse_post_pack_production_peak_bytes": replayed["reuse"]["post_pack_production"],
                "fresh_full_recorded_lifecycle_peak_bytes": replayed["fresh"]["full_recorded_lifecycle"],
                "reuse_full_recorded_lifecycle_peak_bytes": replayed["reuse"]["full_recorded_lifecycle"],
                "rank_values_identical": True,
            }
        )

    n32_windows = next(row for row in allocator_windows_by_n if row["resident_count"] == 32)
    fresh_production_peak = int(n32_windows["fresh_post_pack_production_peak_bytes"])
    reuse_production_peak = int(n32_windows["reuse_post_pack_production_peak_bytes"])
    production_peak_difference = fresh_production_peak - reuse_production_peak
    production_peak_fraction = production_peak_difference / fresh_production_peak
    fresh_lifecycle_peak = int(n32_windows["fresh_full_recorded_lifecycle_peak_bytes"])
    reuse_lifecycle_peak = int(n32_windows["reuse_full_recorded_lifecycle_peak_bytes"])
    lifecycle_peak_difference = fresh_lifecycle_peak - reuse_lifecycle_peak
    lifecycle_peak_fraction = lifecycle_peak_difference / fresh_lifecycle_peak
    require(production_peak_difference == 2_857_268_224, "N=32 production allocator difference drift")
    require(close(production_peak_fraction, 0.038289283508797234), "N=32 production allocator fraction drift")
    require(fresh_lifecycle_peak == 74_623_183_360, "fresh N=32 lifecycle peak drift")
    require(reuse_lifecycle_peak == 72_407_176_192, "reuse N=32 lifecycle peak drift")
    require(lifecycle_peak_difference == 2_216_007_168, "N=32 lifecycle difference drift")
    require(close(lifecycle_peak_fraction, 0.029695961338307614), "N=32 lifecycle fraction drift")

    required_fragments = [
        "504 paired request instances",
        "4,032 paired full-vocabulary step comparisons",
        "8,064 arm-specific model steps",
        "128 of 256 queries",
        "248 larger-fan-out comparisons",
        "80,640 calls",
        "2,857,268,224 bytes",
        "3.8289",
        "2,216,007,168-byte",
        "2.9696",
        "12.33",
        "1.0398",
        "1.0306",
        "post-pack production",
        "full recorded-lifecycle",
        "phase-bounded allocator peaks",
        "not an optimized production full-copy baseline",
        "does not measure continuous batching",
        "not archived directly",
        "same recorded vLLM Python callable",
        "not independent semantic validation",
    ]
    missing = [
        fragment for fragment in required_fragments
        if fragment not in normalized_manuscript
    ]
    require(not missing, f"manuscript is missing required fragments: {missing}")
    ambiguous_fragments = [
        "allocator deltas and absolute peaks",
        "Peak materialize",
        "Peak shared",
    ]
    ambiguous = [fragment for fragment in ambiguous_fragments if fragment in manuscript]
    require(not ambiguous, f"manuscript contains ambiguous peak wording: {ambiguous}")
    require(r"$80(N-1)\mib$" in manuscript, "counterfactual symbolic formula missing")
    require(r"$2,480\mib$" in manuscript, "counterfactual N=32 value missing")

    anonymous_summary = json.loads(ANONYMOUS_SUMMARY.read_text())
    anonymous_shard_paths = sorted(
        ANONYMOUS_SHARDS.glob("multifork-resident-shard-*.json")
    )
    require(len(anonymous_shard_paths) == 8, "anonymous raw shard count drift")
    require(
        anonymous_summary["resident_counts"] == summary["resident_counts"],
        "anonymous resident-count grid drift",
    )
    require(
        anonymous_summary["capacity_matrix"] == summary["capacity_matrix"],
        "anonymous capacity matrix differs from original numeric evidence",
    )
    require(
        anonymous_summary["same_kernel_full_logit_token_logical_kv_gdn_exact_fraction"]
        == summary["same_kernel_full_logit_token_logical_kv_gdn_exact_fraction"],
        "anonymous exactness result drift",
    )
    metrics = json.loads(ARTIFACT_METRICS.read_text())
    require(metrics["evidence_namespace"] == "anonymous_derivative", "artifact namespace drift")
    require(
        metrics["source"]["summary_sha256"] == sha256(ANONYMOUS_SUMMARY),
        "artifact metrics do not bind the distributed anonymous summary",
    )
    metric_capacity_by_n = {
        int(row["resident_count"]): row for row in metrics["capacity"]
    }
    require(set(metric_capacity_by_n) == set(summary["resident_counts"]), "metric N grid drift")
    for replayed in allocator_windows_by_n:
        n = int(replayed["resident_count"])
        metric_row = metric_capacity_by_n[n]
        for key in (
            "fresh_post_pack_production_peak_allocated_bytes",
            "reuse_post_pack_production_peak_allocated_bytes",
            "fresh_full_recorded_lifecycle_peak_allocated_bytes",
            "reuse_full_recorded_lifecycle_peak_allocated_bytes",
        ):
            replay_key = key.replace("_allocated", "")
            require(
                int(metric_row[key]) == int(replayed[replay_key]),
                f"N={n} metric {key} disagrees with raw phase replay",
            )

    audit = {
        "status": "passed",
        "primary_evidence_namespace": "anonymous_derivative",
        "evidence_namespaces": {
            "original_run": {
                "summary_sha256": sha256(SUMMARY),
                "shard_sha256": [sha256(path) for path in shard_paths],
            },
            "anonymous_derivative": {
                "summary_sha256": sha256(ANONYMOUS_SUMMARY),
                "shard_sha256": [sha256(path) for path in anonymous_shard_paths],
                "manifest_sha256": sha256(ANONYMOUS_MANIFEST),
            },
        },
        "manuscript_sha256": sha256(MANUSCRIPT),
        "raw_shards": len(shard_paths),
        "unique_query_hashes": len(unique_query_hashes),
        "paired_request_instances": paired_requests,
        "paired_full_vocab_step_comparisons": paired_generation_steps,
        "arm_specific_model_steps": arm_specific_model_steps,
        "cross_n_coverage": {
            "eligible_unique_queries": 128,
            "singleton_unique_queries": 128,
            "larger_fanout_comparisons": 248,
        },
        "logical_kv_layer_pairs": logical_kv_pairs,
        "gdn_state_pairs": gdn_pairs,
        "fused_attention_calls": fused_calls,
        "allocator_windows_by_n": allocator_windows_by_n,
        "n32": {
            "fresh_pool_mib": fresh_pool / 2**20,
            "reuse_pool_mib": reuse_pool / 2**20,
            "pool_ratio": fresh_pool / reuse_pool,
            "fresh_post_pack_production_peak_bytes": fresh_production_peak,
            "reuse_post_pack_production_peak_bytes": reuse_production_peak,
            "post_pack_production_peak_difference_bytes": production_peak_difference,
            "post_pack_production_peak_difference_gib": production_peak_difference / 2**30,
            "post_pack_production_peak_difference_fraction": production_peak_fraction,
            "fresh_full_recorded_lifecycle_peak_bytes": fresh_lifecycle_peak,
            "reuse_full_recorded_lifecycle_peak_bytes": reuse_lifecycle_peak,
            "full_recorded_lifecycle_peak_difference_bytes": lifecycle_peak_difference,
            "full_recorded_lifecycle_peak_difference_gib": lifecycle_peak_difference / 2**30,
            "full_recorded_lifecycle_peak_difference_fraction": lifecycle_peak_fraction,
            "source_free_counterfactual_fresh_pool_mib": counterfactual_fresh_pool / 2**20,
            "source_free_counterfactual_difference_mib": counterfactual_difference / 2**20,
        },
        "scope_checks": {
            "pg19_train_only": summary["pg19_train_only"],
            "longbench_consumed": summary["longbench_consumed"],
            "test_v2_consumed": summary["test_v2_consumed"],
            "timing_not_aggregated": summary[
                "timing_is_raw_validation_instrumented_single_observation_not_aggregated"
            ],
            "allocator_not_nvml": summary[
                "allocator_absolute_values_are_pytorch_allocator_not_nvml_or_total_model_capacity"
            ],
        },
    }
    OUTPUT.parent.mkdir(parents=True, exist_ok=True)
    OUTPUT.write_text(json.dumps(audit, indent=2, sort_keys=True) + "\n")
    print(json.dumps(audit, indent=2, sort_keys=True))


if __name__ == "__main__":
    main()
