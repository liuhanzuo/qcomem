# Decision log

## 2026-08-16 - Reset from scratch

The previous paper directory was moved to a recoverable archive. The new workspace was initialized from an empty directory and a newly downloaded official ICLR 2026 template. No previous manuscript paragraph or review score is imported.

## 2026-08-16 - ICLR scoring profile

The paper-agent skill now uses only the official ICLR 2026 overall ratings `{2,4,6,8,10}`, Soundness/Presentation/Contribution scores on `{1,2,3,4}`, and confidence on `{1,2,3,4,5}`. Decimal scores, odd overall scores, acceptance probabilities, and weighted pseudo-scores are rejected.

## 2026-08-16 - Candidate stories

1. **HybridFork systems mechanism.** Strong intuitive motivation, but high novelty risk because PagedAttention, RadixAttention, Prompt Cache, Hydragen, ChunkAttention, and Marconi already cover prefix reuse or hybrid prefix caching. Existing evidence lacks a scheduler-level baseline.
2. **ForkBench measurement methodology.** Separates ownership, semantic isolation, physical page pools, framework allocator memory, and service-level memory. Best match to the current auditable evidence, but must not imply cross-engine breadth.
3. **StateFence reliability protocol.** Uses cross-arm and cross-fan-out metamorphic invariants to detect shared-state corruption. Strong correctness story, but mutation breadth and real-bug evidence are limited.

**Selection:** combine candidates 2 and 3 under the working identity **ForkAudit**. The paper contributes an auditable hybrid-state ownership contract and a metamorphic validation protocol, then presents one deliberately narrow systems case study. Capacity arithmetic is supporting evidence, not a claimed empirical scaling law. The earlier working name **StateFork** was retired after a current-web collision check found an unrelated 2026 branchable-agent-environment project using that name.

## Claim boundary selected before drafting

The paper may claim exact equivalence only between the two same-vLLM-kernel ownership arms. It may not claim equivalence to HF eager, downstream quality preservation, scheduler integration, concurrency, latency, throughput, NVML memory, aligned-4096 behavior, Q8/Q4 behavior, or generality across models and hardware.

## 2026-08-16 - Round 0 blind review and evidence ceiling

Five isolated reviewers scored the immutable round-0 snapshot `[6, 4, 4, 4, 4]` on the official ICLR scale; the panel median and meta-score were both 4. The meta-review set an evidence ceiling of 6 without new experiments. The current-evidence revision therefore prioritizes anonymity, package closure, exact count and coverage correction, witness boundaries, and primary-source positioning. It does not attempt to cosmetically optimize toward 8.

## 2026-08-16 - Revision after round 0

- Retitled the paper to **ForkAudit: A Reference Audit of Shared KV Ownership in a Hybrid LLM**.
- Recast every central result as fixed-Python-callable, within-run KV-layout self-consistency under a common functional GDN strategy.
- Corrected nested-prefix coverage to 128/256 unique queries and 248 non-vacuous larger-fan-out comparisons.
- Separated 4,032 paired full-vocabulary comparisons from 8,064 arm-specific model steps.
- Replaced the identifying raw supplement with a dependency-closed anonymous derivative and added manifest, path, and evidence-ID closure checks.
- Added a closest-work table grounded in primary sources and made the source-retaining control and memory denominators explicit.
- Kept independent semantic controls, live runtime mutants, scheduler evaluation, and a second model as unperformed future work rather than implied evidence.

## 2026-08-17 - Round 1 and reviewer-package repair

Five isolated round-1 reviewers all assigned overall rating 4. The meta-review
also assigned 4 and set the current-evidence ceiling to 4: package and prose
repairs could remove integrity defects, but they could not demonstrate runtime
fault sensitivity, an independent semantic oracle, or complete GDN ownership
witnesses. The revision therefore removed reviewer-visible identity leaks,
made the anonymous supplement a self-contained offline replay package, fixed
the source-free counterfactual to $80(N-1)$ MiB, normalized count and witness
terminology, and added primary-source positioning. It did not claim that these
repairs raised the scientific score.

## 2026-08-17 - Round 2 plateau and final integrity revision

The clean, reviewer-safe round-2 snapshot received scores `[4, 4, 4, 6, 4]`
on the official ICLR scale (median 4, mean 4.4; Soundness/Presentation/
Contribution medians 3/3/2). The panel found no critical issue, but retained a
contribution ceiling because the evidence still lacks code-level runtime
mutants, a direct request-to-persistent-base GDN storage witness, an
independent semantic implementation, and a portable clean GPU rerun.

One round-2 finding was repairable from existing raw shards: the manuscript
had called a post-pack production peak an absolute peak. The final integrity
revision now reports two distinct estimands. At $N=32$, the post-pack
production peaks are 74,623,183,360 versus 71,765,915,136 bytes (3.8289%
difference), while maxima over all recorded lifecycle phases are
74,623,183,360 versus 72,407,176,192 bytes (2.9696% difference). The artifact
generator recomputes both from phase snapshots and treats the legacy combined
field only as a consistency check. The final title and contribution statement
also narrow the validated object to full-attention KV ownership under a fixed
GDN treatment, and a deterministic comparison-lattice figure distinguishes
256 unique queries from 504 nested cross-layout request instances.

The blind-review median remained 4 across two consecutive full rounds. Under
the preregistered plateau rule, another prose-only blind round is not useful;
the next rating step requires new experimental evidence. The final manuscript
is therefore a post-round-2 integrity revision, not an unreviewed claim of a
higher score.
