# ForkAudit ICLR 2026 anonymous supplement ZIP

This ZIP is a deterministic packaging of `supplement_anonymous/`. Its internal
`ANONYMOUS_MANIFEST.sha256` binds every included derivative file except the
manifest itself. Infrastructure identifiers and private paths are redacted.
The supplement contains model-output/state digests and runtime equality flags,
not full tensors, model weights, or PG-19 text.
